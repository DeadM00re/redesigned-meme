﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WFA
{
    public class Sales
    {
        public DateTime dtSale { get; set; }
        public int col { get; set; }
        public int marj { get; set; }
        public Employer emp { get; set; }
    }
}
