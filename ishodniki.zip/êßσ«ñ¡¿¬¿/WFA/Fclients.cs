﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFA
{

    public partial class Fclients : Form
    {
        bool UPD;
        public Fclients()
        {
            InitializeComponent();
            UPD = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Удалить запись ?", "Подтвердите действие", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                DBconnectiom db = new DBconnectiom();
                db.openConnection();

                string id = dGView.CurrentRow.Cells[0].Value.ToString();
                string del = "DELETE FROM clients WHERE id =@id";

                try
                {
                    SqlCommand command = new SqlCommand(del, db.getConnection());
                    command.Parameters.Add(new SqlParameter("@id", id));
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка " + ex.Message);
                    return;
                }
                db.closeConnection();
                addToGrid();
            }

        }
        void addToGrid(string sqlstr = @"SELECT * FROM ViewClient")
        {
            DBconnectiom db = new DBconnectiom();
            db.openConnection();

            SqlCommand command = new SqlCommand(sqlstr, db.getConnection());
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            DataSet ds = new DataSet();
            ds.Clear();
            adapter.Fill(ds);
            dGView.DataSource = ds.Tables[0];
            dGView.Columns[0].Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            UPD = true;
            txtFam.Text = dGView.CurrentRow.Cells[1].Value.ToString();
            txtNm.Text = dGView.CurrentRow.Cells[2].Value.ToString();
            txtOtch.Text = dGView.CurrentRow.Cells[3].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DBconnectiom db = new DBconnectiom(); ;
            db.openConnection();

            string fam = txtFam.Text;

            if (fam == "")
            {
                MessageBox.Show("Введите фамилию клиента");
                return;
            }
            try
            {
                SqlCommand command = new SqlCommand();
                command.Connection = db.getConnection();
                if (UPD == true)
                    command.CommandText = "UpdateClient";
                else
                    command.CommandText = "AddClient";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@lastNm", fam));
                command.Parameters.Add(new SqlParameter("@firstNm", txtNm.Text));
                command.Parameters.Add(new SqlParameter("@middleNm", txtOtch.Text));

                if (UPD == true)
                    command.Parameters.Add(new SqlParameter("@id", dGView.CurrentRow.Cells[0].Value.ToString()));
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка " + ex.Message);
                return;
            }
            txtFam.Clear();
            txtNm.Clear();
            txtOtch.Clear();

            db.closeConnection();
            addToGrid();
            if (UPD == true)
            {
                UPD = false;
            }
        }

        private void Fclients_Load(object sender, EventArgs e)
        {
            addToGrid();
        }

        private void txtSearch_KeyUp(object sender, KeyEventArgs e)
        {
            string txt = txtSearch.Text; //строка поиска
            string str = @"SELECT* FROM ViewClient WHERE фамилия LIKE '" + txt + "%' ORDER BY фамилия";

            addToGrid(str);
        }
    }
}
