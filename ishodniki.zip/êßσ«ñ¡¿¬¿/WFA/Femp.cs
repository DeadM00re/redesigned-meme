﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFA
{
    public partial class Femp : Form
    {
        bool UPD;
        public Femp()
        {
            InitializeComponent();
            UPD = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void addToCBox(string sqlStr, ComboBox cBox)
        {
            DBconnectiom db = new DBconnectiom();
            db.openConnection();
            cBox.Items.Add("");
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlStr, db.connectiomStr()))
            {
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                cBox.ValueMember = "id";
                cBox.DisplayMember = "title";
                cBox.DataSource = ds.Tables[0];
            }
            db.closeConnection();
            //  cBox.SelectedIndex = 0;
        }

        private void Femp_Load(object sender, EventArgs e)
        {
            addToCBox("SELECT * FROM doljn order by title", cBox);
            addToGrid();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Удалить запись ?", "Подтвердите действие", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                DBconnectiom db = new DBconnectiom();
                db.openConnection();

                string id = dGView.CurrentRow.Cells[0].Value.ToString();
                string del = "DELETE FROM Employeer WHERE id =@id";

                try
                {
                    SqlCommand command = new SqlCommand(del, db.getConnection());
                    command.Parameters.Add(new SqlParameter("@id", id));
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка " + ex.Message);
                    return;
                }
                db.closeConnection();
                addToGrid();
            }
        }
        void addToGrid(string sqlstr = @"SELECT * FROM ViewEmpl")
        {
            DBconnectiom db = new DBconnectiom();
            db.openConnection();

            SqlCommand command = new SqlCommand(sqlstr, db.getConnection());
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            DataSet ds = new DataSet();
            ds.Clear();
            adapter.Fill(ds);
            dGView.DataSource = ds.Tables[0];
            dGView.Columns[0].Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DBconnectiom db = new DBconnectiom();
            db.openConnection();

            string fam = txtFam.Text;
            string nm = txtNm.Text;
            string otch = txtOtch.Text;

            if (fam == "")
            {
                MessageBox.Show("Введите фамилию сотрудника");
                return;
            }
            try
            {
                SqlCommand command = new SqlCommand();
                command.Connection = db.getConnection();
                command.CommandText = "AddEmployeer";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@lastNm", fam));
                command.Parameters.Add(new SqlParameter("@firstNm", nm));
                command.Parameters.Add(new SqlParameter("@middleNm", otch));
                command.Parameters.Add(new SqlParameter("@dtBrth", dTPbirthDay.Value.ToString("yyyy-MM-dd")));
                command.Parameters.Add(new SqlParameter("@dtWrk", dTPbirthDay.Value.ToString("yyyy-MM-dd")));
                command.Parameters.Add(new SqlParameter("@phone",textBox1.Text));
                command.Parameters.Add(new SqlParameter("@doljn", cBox.SelectedValue));
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка " + ex.Message);
                return;
            }
            txtFam.Clear();
            txtNm.Clear();
            txtOtch.Clear();

            db.closeConnection();
            addToGrid();
        }

        private void txtSearch_KeyUp(object sender, KeyEventArgs e)
        {
            string txt = txtSearch.Text; //строка поиска
            string str = @"SELECT* FROM ViewEmpl WHERE фамилия LIKE '" + txt + "%' ORDER BY фамилия";

            addToGrid(str);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            UPD = true;
        }
    }
}
