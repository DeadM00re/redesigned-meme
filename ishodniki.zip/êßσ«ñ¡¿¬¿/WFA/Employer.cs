﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WFA
{
    public class Employer
    {
        public int id { get; set; }
        public string fam { get; set; }
        public string nm { get; set; }
        public string mdl { get; set; }
        public string phone { get; set; }
        public DateTime dtBrth { get; set; }
        public DateTime dtWrk { get; set; }
        public Doljn doljn { get; set; }
    }
}
