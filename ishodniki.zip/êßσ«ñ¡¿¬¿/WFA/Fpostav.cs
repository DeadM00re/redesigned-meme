﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFA
{
    public partial class Fpostav : Form
    {
        bool UPD;
        public Fpostav()
        {
            InitializeComponent();
            UPD = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Удалить запись ?", "Подтвердите действие", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                DBconnectiom db = new DBconnectiom();
                db.openConnection();

                string id = dGView.CurrentRow.Cells[0].Value.ToString();
                string del = "DELETE FROM postav WHERE id =@id";

                try
                {
                    SqlCommand command = new SqlCommand(del, db.getConnection());
                    command.Parameters.Add(new SqlParameter("@id", id));
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка " + ex.Message);
                    return;
                }
                db.closeConnection();
                addToGrid();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DBconnectiom db = new DBconnectiom();
            db.openConnection();

            string fam = txtFam.Text;
            if (fam == "")
            {
                MessageBox.Show("Введите название поставщика");
                return;
            }
            try
            {
                SqlCommand command = new SqlCommand();
                command.Connection = db.getConnection();
                if (UPD == true)
                    command.CommandText = "UpdateVendor";
                else
                    command.CommandText = "AddVendor";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@title", fam));
                command.Parameters.Add(new SqlParameter("@adress", txtFull.Text));
                command.Parameters.Add(new SqlParameter("@phone", txtPhone.Text));

                if (UPD == true)
                    command.Parameters.Add(new SqlParameter("@id", dGView.CurrentRow.Cells[0].Value.ToString()));
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка " + ex.Message);
                return;
            }
            txtFam.Clear();
            txtFull.Clear();
            txtPhone.Clear();

            db.closeConnection();
            addToGrid();

            if (UPD == true)
            {
                UPD = false;
            }
        }
        void addToGrid(string sqlstr = @"SELECT id, title AS название, adress AS адрес, phone AS телефон FROM vendor")
        {
            DBconnectiom db = new DBconnectiom();
            db.openConnection();

            SqlCommand command = new SqlCommand(sqlstr, db.getConnection());
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            DataSet ds = new DataSet();
            ds.Clear();
            adapter.Fill(ds);
            dGView.DataSource = ds.Tables[0];
            dGView.Columns[0].Visible = false;
        }

        private void Fcountry_Load(object sender, EventArgs e)
        {
            addToGrid();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            UPD = true;
            txtFam.Text = dGView.CurrentRow.Cells[1].Value.ToString();
            txtFull.Text = dGView.CurrentRow.Cells[2].Value.ToString();
            txtPhone.Text = dGView.CurrentRow.Cells[3].Value.ToString();
        }
    }
}
