﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;

namespace WFA
{
    public partial class Fmain : Form
    {
        public Fmain()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            Fpostavki fvisit = new Fpostavki();
            fvisit.ShowDialog();

        }

        private void button9_Click(object sender, EventArgs e)
        {
            Fsale fsale = new Fsale();
            fsale.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void Fmain_Load(object sender, EventArgs e)
        {
            addToGrid();
        }
        void addToGrid(string sqlstr = @"SELECT * FROM ViewSale ORDER BY [дата продажи]")
        {
            DBconnectiom db = new DBconnectiom();
            db.openConnection();

            SqlCommand command = new SqlCommand(sqlstr, db.getConnection());
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            DataSet ds = new DataSet();
            ds.Clear();
            adapter.Fill(ds);
            dGView.DataSource = ds.Tables[0];
            dGView.Columns[0].Visible = false;
            db.closeConnection();
        }

        private void преподавателиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Femp femp = new Femp();
            femp.ShowDialog();
        }

        private void предметыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Fpostavki fitems = new Fpostavki();
            fitems.ShowDialog();
        }

        private void страныToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Femp femp = new Femp();
            femp.ShowDialog();
        }

        private void студентыToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void группыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Fproizvod fgroup = new Fproizvod();
            fgroup.ShowDialog();
        }


        private void производителиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Fproizvod fproizvod = new Fproizvod();
            fproizvod.ShowDialog();
        }

        private void поставщикиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Fpostav fpostav = new Fpostav();
            fpostav.ShowDialog();
        }

        private void rBAll_CheckedChanged_1(object sender, EventArgs e)
        {
            addToGrid(@"SELECT * FROM ViewSale ORDER BY [дата продажи]");
        }

        private void rbData_CheckedChanged(object sender, EventArgs e)
        {
            string str = @"SELECT * FROM ViewSale WHERE [дата продажи] = '" + dateTimePicker1.Value.ToString("dd.MM.yyyy") + "'";
            addToGrid(str);
        }

        private void клиентыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Fclients fclients = new Fclients();
            fclients.ShowDialog();
        }
        private void товарМагазинаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Fitems fitems = new Fitems();
            fitems.ShowDialog();
        }
    }
}
