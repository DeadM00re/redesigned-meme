﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFA
{
    public partial class Fmain : Form
    {
        public Fmain()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Fclients fclients = new Fclients();
            fclients.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Fspec fspec = new Fspec();
            fspec.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Fusluga fusluga = new Fusluga();
            fusluga.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Femp femp = new Femp();
            femp.ShowDialog();
        }
    }
}
