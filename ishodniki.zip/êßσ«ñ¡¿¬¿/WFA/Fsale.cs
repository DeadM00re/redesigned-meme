﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFA
{
    public partial class Fsale : Form
    {
        public Fsale()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Удалить запись ?", "Подтвердите действие", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {

                DBconnectiom db = new DBconnectiom();
                db.openConnection();

                string id = dGView.CurrentRow.Cells[0].Value.ToString();
                string del = "DELETE FROM sale WHERE id =@id";

                try
                {
                    SqlCommand command = new SqlCommand(del, db.getConnection());
                    command.Parameters.Add(new SqlParameter("@id", id));
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка " + ex.Message);
                    return;
                }
                db.closeConnection();
                string str = @"SELECT * FROM ViewSale WHERE [дата продажи] = '" + dateTimePicker1.Value.ToString("dd.MM.yyyy") + "'";
                addToGrid(str);

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DBconnectiom db = new DBconnectiom();
            db.openConnection();
            try
            {
                SqlCommand command = new SqlCommand();
                command.Connection = db.getConnection();
                command.CommandText = "AddSale";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@delivires", cBoxItems.SelectedValue));
                command.Parameters.Add(new SqlParameter("@dtSale", dateTimePicker1.Value.ToString("yyyy-MM-dd")));
                command.Parameters.Add(new SqlParameter("@kol", txtKol.Text));
                command.Parameters.Add(new SqlParameter("@percnt", txtPer.Text));
                command.Parameters.Add(new SqlParameter("@seller", cBoxSeller.SelectedValue));
                command.Parameters.Add(new SqlParameter("@clients", cBoxClient.SelectedValue));
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка " + ex.Message);
                return;
            }
            db.closeConnection();
            string str = @"SELECT * FROM ViewSale WHERE [дата продажи] = '" + dateTimePicker1.Value.ToString("dd.MM.yyyy") + "'";
            addToGrid(str);
        }
        void addToGrid(string sqlstr = @"SELECT * FROM ViewSale ORDER BY [дата продажи]")
        {
            DBconnectiom db = new DBconnectiom();
            db.openConnection();

            SqlCommand command = new SqlCommand(sqlstr, db.getConnection());
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            DataSet ds = new DataSet();
            ds.Clear();
            adapter.Fill(ds);
            dGView.DataSource = ds.Tables[0];
            dGView.Columns[0].Visible = false;
            db.closeConnection();
        }

        private void Fitems_Load(object sender, EventArgs e)
        {
            addToCBox(@"SELECT id, CONCAT(фамилия,' ', LEFT(имя, 1) + '.' + ISNULL(SUBSTRING(отчество, 1, 1) + '.', ''))
                    AS 'title' FROM ViewEmpl WHERE должность = 'Менеджер по продажам'", cBoxSeller);
            addToCBox(@"SELECT id, CONCAT(товар,', цена: ',цена) title FROM ViewDelivery", cBoxItems);
            addToCBox(@"SELECT id, CONCAT(фамилия, ' ', LEFT(имя, 1) + '.' + ISNULL(SUBSTRING(отчество, 1, 1) + '.', ''))
                    AS 'title' FROM ViewClient", cBoxClient);
            addToGrid(@"SELECT * FROM ViewSale WHERE [дата продажи] = '" + dateTimePicker1.Value.ToString("dd.MM.yyyy") + "'");

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            string str = @"SELECT * FROM ViewSale WHERE [дата продажи] = '" + dateTimePicker1.Value.ToString("dd.MM.yyyy") + "'";
            addToGrid(str);
        }
        private void addToCBox(string sqlStr, ComboBox cBox)
        {
            DBconnectiom db = new DBconnectiom();
            db.openConnection();
            cBox.Items.Add("");
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlStr, db.connectiomStr()))
            {
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                cBox.ValueMember = "id";
                cBox.DisplayMember = "title";
                cBox.DataSource = ds.Tables[0];
            }
            db.closeConnection();
        }
    }
}
