﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WFA
{
    public partial class Fpostavki : Form
    {
        string str;
        public Fpostavki()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            DBconnectiom db = new DBconnectiom();
            db.openConnection();

            Double cana;
            try
            {
                cana = Double.Parse(txtCana.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка " + ex.Message);
                return;   
            }
            try
            {
                SqlCommand command = new SqlCommand();
                command.Connection = db.getConnection();
                command.CommandText = "AddDelivire";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@items", cBoxItems.SelectedValue));
                command.Parameters.Add(new SqlParameter("@creator", cBoxProizvod.SelectedValue));
                command.Parameters.Add(new SqlParameter("@vendor", cBoxPostav.SelectedValue));
                command.Parameters.Add(new SqlParameter("@dtArrival", dateTimePicker1.Value.ToString("yyyy-MM-dd")));
                command.Parameters.Add(new SqlParameter("@kol", txtKol.Text));
                command.Parameters.Add(new SqlParameter("@cost", txtCana.Text));
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка " + ex.Message);
                return;
            }
            db.closeConnection();

            addToGrid("SELECT * FROM ViewDelivery ORDER BY [дата прибытия]");
        }
        void addToGrid(string sqlstr = "SELECT * FROM ViewDelivery ORDER BY [дата прибытия]")
        {

            DBconnectiom db = new DBconnectiom();
            db.openConnection();

            SqlCommand command = new SqlCommand(sqlstr, db.getConnection());
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            DataSet ds = new DataSet();
            ds.Clear();
            adapter.Fill(ds);
            dGView.DataSource = ds.Tables[0];
            dGView.Columns[0].Visible = false;
            db.closeConnection();
        }
        private void addToCBox(string sqlStr, ComboBox cBox)
        {

            DBconnectiom db = new DBconnectiom();
            db.openConnection();

            cBox.Items.Add("");
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlStr, db.connectiomStr()))
            {
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                cBox.ValueMember = "id";
                cBox.DisplayMember = "title";
                cBox.DataSource = ds.Tables[0];
            }
            db.closeConnection();
           
        }

        private void button3_Click(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show("Удалить запись ?", "Подтвердите действие", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {

                DBconnectiom db = new DBconnectiom();
                db.openConnection();

                string id = dGView.CurrentRow.Cells[0].Value.ToString();
                string del = "DELETE FROM Delivires WHERE id =@id";

                try
                {
                    SqlCommand command = new SqlCommand(del, db.getConnection());
                    command.Parameters.Add(new SqlParameter("@id", id));
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка " + ex.Message);
                    return;
                }
                db.closeConnection();
                addToGrid();
                
            }
        }

        private void Fvisit_Load(object sender, EventArgs e)
        {
            addToGrid();
            addToCBox("SELECT * FROM Items", cBoxItems);
            addToCBox("SELECT * FROM Vendor", cBoxPostav);
            addToCBox("SELECT * FROM Creator", cBoxProizvod);
        }
    }
}
