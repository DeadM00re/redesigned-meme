﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFA
{
    public partial class Fitems : Form
    {
        bool UPD;
        public Fitems()
        {
            InitializeComponent();
            UPD = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Удалить запись ?", "Подтвердите действие", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                DBconnectiom db = new DBconnectiom();
                db.openConnection();

                string id = dGView.CurrentRow.Cells[0].Value.ToString();
                string del = "DELETE FROM items WHERE id =@id";

                try
                {
                    SqlCommand command = new SqlCommand(del, db.getConnection());
                    command.Parameters.Add(new SqlParameter("@id", id));
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка " + ex.Message);
                    return;
                }
                db.closeConnection();
                addToGrid();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DBconnectiom db = new DBconnectiom(); ;
            db.openConnection();

            string fam = txtFam.Text;

            if (fam == "")
            {
                MessageBox.Show("Введите фамилию клиента");
                return;
            }
            try
            {
                SqlCommand command = new SqlCommand();
                command.Connection = db.getConnection();
                if (UPD == true)
                    command.CommandText = "UpdateItem";
                else
                    command.CommandText = "AddItem";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@title", fam));
                command.Parameters.Add(new SqlParameter("@category", cBox.SelectedValue));

                if (UPD == true)
                    command.Parameters.Add(new SqlParameter("@id", dGView.CurrentRow.Cells[0].Value.ToString()));
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка " + ex.Message);
                return;
            }
            txtFam.Clear();

            db.closeConnection();
            addToGrid();
            if (UPD == true)
            {
                UPD = false;
            }
        }
        private void addToCBox(string sqlStr, ComboBox cBox)
        {
            DBconnectiom db = new DBconnectiom();
            db.openConnection();
            cBox.Items.Add("");
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlStr, db.connectiomStr()))
            {
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                cBox.ValueMember = "id";
                cBox.DisplayMember = "title";
                cBox.DataSource = ds.Tables[0];
            }
            db.closeConnection();
            //  cBox.SelectedIndex = 0;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            UPD = true;
            txtFam.Text = dGView.CurrentRow.Cells[1].Value.ToString();
        }
        void addToGrid(string sqlstr = @"SELECT * FROM ViewItems")
        {
            DBconnectiom db = new DBconnectiom();
            db.openConnection();

            SqlCommand command = new SqlCommand(sqlstr, db.getConnection());
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = command;
            DataSet ds = new DataSet();
            ds.Clear();
            adapter.Fill(ds);
            dGView.DataSource = ds.Tables[0];
            dGView.Columns[0].Visible = false;
        }

        private void Fauth_Load(object sender, EventArgs e)
        {
            addToGrid();
            addToCBox("SELECT * FROM category", cBox);
        }
    }
}
